CHATGPT HANDOFF V1.0

Source :
C:\Users\Aharr\Desktop\JobHunter - Copie\exports\logs\final_application_pool_v12_20260819_001713.json

Pool source :
1.2

Actions :
APPLY_NOW

Candidatures exportées :
4

CV de base préféré :
CV_Oussama_Aharroud_LabQC.docx

UTILISATION
-----------
1. Envoyer à ChatGPT un ZIP de lot.
2. Lui demander de traiter les candidatures une par une.
3. Pour chaque offre, ChatGPT doit d'abord vérifier l'éligibilité sur
   job.json puis générer CV Word + lettre Word sans rien inventer.
4. Ne jamais marquer une offre APPLIED tant que la candidature n'a pas
   réellement été envoyée.
