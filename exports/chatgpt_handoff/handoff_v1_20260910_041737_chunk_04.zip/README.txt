CHATGPT HANDOFF V1.0

Source :
C:\Users\Aharr\Desktop\JobHunter - Copie\exports\logs\final_application_pool_v12_20260910_041734.json

Pool source :
1.3

Actions :
APPLY_NOW

Candidatures exportées :
74

CV de base préféré :
CV_Oussama_Aharroud_LabQC.docx

FICHIERS GLOBAUX
----------------
candidate_truth.json
application_instructions.json
CV_Oussama_Aharroud_LabQC.docx

Chaque job.json contient uniquement les données propres à l'offre.

UTILISATION
-----------
1. Envoyer à ChatGPT un ZIP de lot.
2. Lui demander de traiter les candidatures une par une.
3. Pour chaque offre, ChatGPT doit d'abord vérifier l'éligibilité sur
   job.json puis générer CV Word + lettre Word sans rien inventer.
4. Ne jamais marquer une offre APPLIED tant que la candidature n'a pas
   réellement été envoyée.
